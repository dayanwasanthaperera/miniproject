## This is the Test Sript of Create country data 

```cs
 
Create EnterpriseHandling.svc/TrnCountries
{
  "CountryId": "DUB",
  "Country": "Dubai"
}
 
```